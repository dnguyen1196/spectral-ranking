#file to clean up votes data, and to divide it based on emotions/expressions

import re
import numpy
import csv
import pandas as pd
import os


dir = os.getcwd()

print dir


data_metrics = pd.read_csv('metrics.csv', sep=',')
data_votes = pd.read_csv('votes.csv', sep=',')

total = 0



for index1, row1 in data_metrics.iterrows():
    
    exp_id = row1['exp_id']
    
    d = dict([('zero', 0)])
    count = 1
    data_votes_temp = data_votes[data_votes['exp_id'] == exp_id][['item1', 'item2', 'winner']]
    
    #print data_votes_temp.item1.nunique()
    #print data_votes_temp.item2.nunique()
    
    #print data_votes_temp.head()
    
    for index, row in data_votes_temp.iterrows():

        if row['item1'] in d:
            row['item1'] = d.get(row['item1'])            
        else:
            d.update([(row['item1'], count)])
            row['item1'] = count
            count = count + 1
        if row['item2'] in d:
            row['item2'] = d.get(row['item2'])            
        else:
            d.update([(row['item2'], count)])
            row['item2'] = count
            count = count + 1
        row['winner'] = d.get(row['winner']) 
        
    print '../GIF-'+row1['expression']
    path = os.path.join(dir, '../GIF-'+row1['expression'])
    


    if not os.path.exists(path):
        os.makedirs(path)
       
    data_votes_temp.to_csv(path + '/GIF-'+row1['expression']+'.csv', index=False)
    
#    x.name.astype('category').cat.rename_categories(range(1, x.name.nunique()+1))
#    data_votes_temp = data_votes_temp[['item1', 'item2', 'winner']]


    #print data_votes_temp.item1.nunique()
    #print data_votes_temp.item2.nunique()
    
    #print data_votes_temp.head()
    
    
    #print data_votes_temp.item1.astype('category').cat.rename_categories(range(1, data_votes_temp.item1.nunique()+1)).shape
    #data_votes_temp.item1.unique()
    #print data_votes_temp.item2.unique()


    
    total = total + data_votes_temp.shape[0]

print total