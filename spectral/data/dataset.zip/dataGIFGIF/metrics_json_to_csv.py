import re
import csv
with open('metrics.csv', 'w') as csvfile:
    fieldnames = ['exp_id', 'expression']
    writer = csv.DictWriter(csvfile, fieldnames=fieldnames)
    writer.writeheader()
    with open('metrics.json') as f:
        for line in f:
            x = re.findall(r'"([^"]*)"', line)
            writer.writerow({'exp_id': x[2], 'expression': x[4]})

