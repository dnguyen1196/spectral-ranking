#file to convert json data to csv format plus remove ties

import re
import numpy
import csv

with open('votes.csv', 'w') as csvfile:
    fieldnames = ['exp_id', 'item1', 'item2', 'winner']
    writer = csv.DictWriter(csvfile, fieldnames=fieldnames)
    writer.writeheader()
    with open('votes.json') as f:
        for line in f:
            x = re.findall(r'"([^"]*)"', line)
            y = [int(s) for s in line.replace(',',' ').split() if s.isdigit()]
            if y[2] > y[1]:
                writer.writerow({'exp_id': x[4], 'item1': x[7], 'item2': x[8], 'winner': x[8] })
            if y[1] > y[2]:
                writer.writerow({'exp_id': x[4], 'item1': x[7], 'item2': x[8], 'winner': x[7]})


